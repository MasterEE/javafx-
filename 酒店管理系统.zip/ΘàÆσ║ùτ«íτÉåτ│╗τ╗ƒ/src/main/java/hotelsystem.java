import javax.swing.*;

public class hotelsystem {
    private JTextField Username;
    private JPasswordField Password;
    private JButton Enter;




}
